import random

print("""
          Welcome to my Rocks paper and scissors game """)
str1=["rock","paper","scissors"]
score_user=0
score_comp=0
list1=[]
for i in range(0,3):
    user_choice=input("Enter your choice\n")
    t=(random.randint(0,2))
    comp_choice=str1[t]
    if(user_choice=="rock"):
        if(comp_choice=="rock"):
            print("draw")
            score_user+=0
            score_comp+=0
           
        if(comp_choice=="scissors"):
            print("User wins")
            score_user+=1
        if(comp_choice=="paper"):
            print("Computer wins")
            score_comp+=1
    elif(user_choice=="scissors"):
        if(comp_choice=="scissors"):
            print("It's a Draw")
            score_user+=0
            score_comp+=0
        if(comp_choice=="rock"):
            print("Computer Wins")
            score_comp+=1
        if(comp_choice=="paper"):
            print("User wins")
            score_user+=1
    elif(user_choice=="paper"):
        if(comp_choice=="paper"):
            print("It's a Draw")
            score_user+=0
            score_comp+=0
        if(comp_choice=="rock"):
            print("User wins")
            score_user+=1
        if(comp_choice=="scissors"):
            print("Computer wins")
            score_comp+=1
    list1.append(user_choice)
    list1.append(comp_choice)  

print("The user's score is",score_user)
print("The computer's score is",score_comp)

if(score_user>score_comp):
    print("User wins")
    print("His score is ",score_user)
elif(score_comp>score_user):
    print("Computer wins")
    print("The score is",score_comp)   
else:
    print("It's a Draw")
    
print("In the first round")
print("The user input was",list1[0])
print("The comp input was",list1[1])
print("In the second round")
print("The user input was",list1[2])
print("The comp input was",list1[3])
print("In the third round")
print("The user input was",list1[4])
print("The comp input was",list1[5])
