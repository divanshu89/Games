The Technology that i have used:
Python 3.7
Instructions To Execute the file:
For Windows(7,8,10)
1)Install python 3.7 on your machine with default settings.
2)Download the file and place it on the desktop.
3)Open the command prompt by typing cmd on the search
4)Drag and drop the file on the cmd
5)It will automatically execute,have fun playing the game

Creator-
Divanshu Joshi